import sqlite3
con = sqlite3.connect("Bank Management.db")
cu=con.cursor()

#----------------------------------------------------------------------------------------------------------
                                #Account Management Tables
#----------------------------------------------------------------------------------------------------------

# ------------------------------CUSTOMER TABLE-------------------------------------------------------------
cu.execute("""
            CREATE TABLE IF NOT EXISTS CUSTOMER_DETAILS(
            C_ID TEXT PRIMARY KEY NOT NULL,
            FULL_NAME TEXT NOT NULL,
            DATE_OF_BIRTH TEXT NOT NULL,
            ADRESS CHAR(50) NOT NULL,
            PHONE_NUMBER INT NOT NULL,
            EMAIL_ID TEXT,
            NATIONAL_ID_PASSPORT TEXT NOT NULL
            );
""")
# ------------------------------ACCOUNT TABLE-------------------------------------------------------------
cu.execute("""
            CREATE TABLE IF NOT EXISTS ACCOUNT_DETAILS(
            C_ID TEXT PRIMARY KEY NOT NULL,
            ACCOUNT_ID TEXT NOT NULL,
            ACCOUNT_TYPE TEXT NOT NULL,
            ACCOUNT_NUMBER NOT NULL,
            BALANCE REAL NOT NULL,
            DATE_OPEN TEXT,
            STATUS TEXT
            );
""")
# ------------------------------SAVING ACCOUNT TABLE-------------------------------------------------------------
cu.execute("""
            CREATE TABLE IF NOT EXISTS SAVING_ACCOUNT_DETAILS(
            C_ID TEXT PRIMARY KEY NOT NULL,
            ACCOUNT_ID TEXT NOT NULL,
            ACCOUNT_TYPE TEXT NOT NULL,
            ACCOUNT_NUMBER NOT NULL,
            BALANCE REAL NOT NULL,
            DATE_OPEN TEXT,
            STATUS TEXT
            );
""")
# ------------------------------CURRENT ACCOUNT TABLE-------------------------------------------------------------
cu.execute("""
            CREATE TABLE IF NOT EXISTS CURRENT_ACCOUNT_DETAILS(
            C_ID TEXT PRIMARY KEY NOT NULL,
            ACCOUNT_ID TEXT NOT NULL,
            ACCOUNT_TYPE TEXT NOT NULL,
            ACCOUNT_NUMBER NOT NULL,
            BALANCE REAL NOT NULL,
            DATE_OPEN TEXT,
            STATUS TEXT
            );
""")
# ------------------------------FIXED ACCOUNT TABLE-------------------------------------------------------------
cu.execute("""
            CREATE TABLE IF NOT EXISTS FIXED_ACCOUNT_DETAILS(
            C_ID TEXT PRIMARY KEY NOT NULL,
            ACCOUNT_ID TEXT NOT NULL,
            ACCOUNT_TYPE TEXT NOT NULL,
            ACCOUNT_NUMBER NOT NULL,
            BALANCE REAL NOT NULL,
            DATE_OPEN TEXT,
            STATUS TEXT
            );
""")

#----------------------------------------------------------------------------------------------------------
                                # TRANSACTION TABLES
#----------------------------------------------------------------------------------------------------------

# ------------------------------DEPOSITE DETAIL TABLE------------------------------------------------------
cu.execute("""
            CREATE TABLE IF NOT EXISTS DEPOSITE_DETAILS(
            DEPOSITE_ID TEXT PRIMARY KEY NOT NULL,
            C_ID TEXT NOT NULL,
            DEPOSITE_AMOUNT REAL NOT NULL,
            DATE TEXT NOT NULL,
            TIME TEXT NOT NULL,
            TRANSACATION_MODE TEXT NOT NULL,
            BRANCH_ID TEXT,
            REFERANCE_NO TEXT,
            STAFF_ID TEXT
            );
""")
# ------------------------------WITHDRAW DETAIL TABLE------------------------------------------------------
cu.execute("""
            CREATE TABLE IF NOT EXISTS WITHDRAW_DETAILS(
            WITHDRAW_ID TEXT PRIMARY KEY NOT NULL,
            C_ID TEXT NOT NULL,
            WITHDRAW_AMOUNT REAL NOT NULL,
            DATE TEXT NOT NULL,
            TIME TEXT NOT NULL,
            TRANSACATION_MODE TEXT NOT NULL,
            BRANCH_ID TEXT,
            REFERANCE_NO TEXT,
            STAFF_ID TEXT
            );
""")
# ------------------------------TRANSFER DETAIL TABLE------------------------------------------------------
cu.execute("""
            CREATE TABLE IF NOT EXISTS TRANSFER_DETAILS(
            TRANSFER_ID TEXT PRIMARY KEY NOT NULL,
            C_ID TEXT NOT NULL,
            TRANSFER_AMOUNT REAL NOT NULL,
            DATE TEXT NOT NULL,
            TIME TEXT NOT NULL,
            TRANSACATION_MODE TEXT NOT NULL,
            T_C_ID TEXT,
            REFERANCE_NO TEXT,
            STAFF_ID TEXT
            );
""")

#----------------------------------------------------------------------------------------------------------
                                # ADMINISTRATION TABLES
#----------------------------------------------------------------------------------------------------------

# ------------------------------STAFF DETAILS TABLE--------------------------------------------------------
cu.execute("""
            CREATE TABLE IF NOT EXISTS STAFF_DETAILS(
            STAFF_ID TEXT PRIMARY KEY NOT NULL,
            POSITION TEXT NOT NULL,
            STAF_NAME TEXT NOT NULL,
            JOIN_DATE TEXT NOT NULL,
            ADRESS CHAR(50),
            PHONE_NUMBER INT NOT NULL,
            EMAIL_ID TEXT,
            NATIONAL_ID_PASSPORT TEXT,
            BRANCH_ID
            );
""")
# ------------------------------CUSTOMER LOGIN TABLE---------------------------------------------------------------
cu.execute("""
            CREATE TABLE IF NOT EXISTS CUSTOMER_LOGIN(
            USER_NAME TEXT PRIMARY KEY NOT NULL,
            PASSWORD TEXT NOT NULL,
            PERMISSION_TYPE TEXT NOT NULL,
            C_ID TEXT
            );
""")
# ------------------------------STAFF LOGIN TABLE---------------------------------------------------------------
cu.execute("""
            CREATE TABLE IF NOT EXISTS STAFF_LOGIN(
            USER_NAME TEXT PRIMARY KEY NOT NULL,
            PASSWORD TEXT NOT NULL,
            PERMISSION_TYPE TEXT NOT NULL,
            STAFF_ID TEXT
            );
""")
print("----------------------------------------------------------------------------------------------------------")
print("\n")
print("                        The database has been created successfully.")
print("\n")
print("----------------------------------------------------------------------------------------------------------")