import sqlite3
import datetime
import re

con = sqlite3.connect("Bank Management.db")
cu=con.cursor()


Date = datetime.datetime.now()
Date_today = Date.strftime("%x")
C_Time = Date.strftime("%X")

a=True
Customer_Name = ""
Customer_Account_No = 0
Choice = 1
Staff_Name = "Binil"
Permission_type = "" 




#-------------------------------------------------------Welcome Page------------------------------------------------------------------------------
def display_Menu():
    print("--------------------------------------------------------------------------------------------------------------")
    print("                                         Bank Management System")
    print("--------------------------------------------------------------------------------------------------------------")
    print("\n")
    print("                                 Welcome! Please choose your login type:")
    print("\n")

    print("                                         1. Customer Login")
    print("                                         2. Staff Login")
    print("                                         3. Sign-UP    ")
    print("\n")
    Choice = input("                    Please Enter your choice (1 - 3): ")
    Login_Selection(Choice)
    print("\n")
#-----------------------------------------------------------------------------------------------------------------------------------------------
def Login_Selection(Choice):
    if Choice == "1":
        Customer_login()
    elif Choice == "2":
        Staff_login()
    elif Choice == "3":
        Sign_up_Details()
    else:
        print("--------------------------------------------------------------------------------------------------------------")
        print("Invalid Entry , Please Enter the Choice (1-3)")
        print("--------------------------------------------------------------------------------------------------------------")
        display_Menu()
#------------------------------------------------------------------------------------------------------------------------------




def Customer_login():
    print("--------------------------------------------------------------------------------------------------------------")
    print("                                         CUSTOMER LOGIN")
    print("--------------------------------------------------------------------------------------------------------------")
    print("\n")
    print("                             PLEASE ENTER THE USER NAME AND PASSWORD")
    print("\n")
    Customer_UserName =input("                    Please Enter the User name : ")
    Customer_Password =input("                    Please Enter the Password  : ")
    print("\n")
    Login_Authentication(Customer_UserName,Customer_Password)
#------------------------------------------------------------------------------------------------------------------------------------


def Customer_dashboard(User_Details,U_accunt_No,User_c_id,):
    global Customer_Account_No_Global 
    print("--------------------------------------------------------------------------------------------------------------")
    print("                                         CUSTOMER DASHBOARD")
    print("--------------------------------------------------------------------------------------------------------------")
    print("\n")
    print("                             Welcome , ", User_Details ,"!")
    print("                             Account Number : ", U_accunt_No )
    print("\n")
    print("                                         1. Check Balance")
    print("                                         2. Deposite Money")
    print("                                         3. Withdraw Money")
    print("                                         4. Transfer Money")
    print("                                         5. Mini Statement")
    print("                                         6. Change Password")
    print("                                         7. Account Details")
    print("                                         8. Logout")
    print("\n")

    User_ID = User_c_id
    Customer_Account_No_Global = U_accunt_No
    try:
        Choice = int(input("                    Please Enter your choice (1 - 8): "))
        Customer_Choice_board(Choice,User_ID) # call choice function
    except ValueError:
        print("Please enter numbers only.")
        Customer_dashboard() # call choice function again
    print("\n")
#------------------------------------------------------------------------------------------------------------------------------------

def Staff_login():
    print("--------------------------------------------------------------------------------------------------------------")
    print("                                         STAFF LOGIN")
    print("--------------------------------------------------------------------------------------------------------------")
    print("\n")
    print("                             PLEASE ENTER THE USER NAME AND PASSWORD")
    print("\n")
    Customer_UserName =input("                    Please Enter the User name : ")
    Customer_Password =input("                    Please Enter the Password  : ")
    print("\n")
    Staff_Login_Authentication(Customer_UserName,Customer_Password)
#------------------------------------------------------------------------------------------------------------------------------------
def Staff_dashboard(Staff_Name):
    print("--------------------------------------------------------------------------------------------------------------")
    print("                                         STAFF DASHBOARD")
    print("--------------------------------------------------------------------------------------------------------------")
    print("\n")
    print("                             Welcome , ", Staff_Name ,"!")
    print("\n")
    print("                                         1. View Customer Accounts")
    print("                                         2. Search Customer")
    print("                                         3. Create Customer Account")
    print("                                         4. Delete Customer Account")
    print("                                         5. Change Password")
    print("                                         6. Logout")
    print("\n")

    try:
        Choice = int(input("                    Please Enter your choice (1 - 9): "))
        Staff_Choice_board(Choice) # call choice function
    except ValueError:
        print("Please enter numbers only.")
        Staff_dashboard(Staff_Name) # call Staff_dashboard again

    print("\n")
#------------------------------------------------------------------------------------------------------------------------------------


#-----------------------------------------------SIGN UP Details------------------------------------------------------------
def Sign_up_Details():
    print("--------------------------------------------------------------------------------------------------------------")
    print("                                             SIGN-UP")
    print("--------------------------------------------------------------------------------------------------------------")
    print("\n")
    print("                                       SIGN UP FOR EASY BANKING")
    print("\n")
    Customer_Name =input("                        Please Enter the Name : ")
    Customer_DOB = input("                        Please Enter the Date Of Birth(DD-MM-YYYY)  : ")
    Customer_AC_NO =input("                        Please Enter the Account Number : ")
    Customer_UserName = input("                        Please Enter The User Name      :")
    Customer_Password =input("                        Please Enter the Password       : ")
    print("\n")
    Sign_up_1(Customer_Name,Customer_DOB,Customer_AC_NO,Customer_UserName,Customer_Password)
#------------------------------------------------------------------------------------------------------------------------------------

def Sign_up_1(Customer_Name,Customer_DOB,Customer_AC_NO,Customer_UserName,Customer_Password):
    cu.execute("SELECT C_ID FROM CUSTOMER_DETAILS WHERE FULL_NAME =? AND DATE_OF_BIRTH = ?",(Customer_Name,Customer_DOB,))
    Result_01 = cu.fetchall()
    if Result_01:
        Customer_ID =Result_01[0][0]
        cu.execute("SELECT ACCOUNT_NUMBER FROM ACCOUNT_DETAILS WHERE C_ID =?",(Customer_ID,))
        Result_02 = cu.fetchall()
        C_AccountNO1 = Result_02[0][0]
        if C_AccountNO1 == Customer_AC_NO:
            cu.execute("SELECT USER_NAME FROM CUSTOMER_LOGIN WHERE C_ID =?",(Customer_ID,))
            Result_03 = cu.fetchall()
            if Result_03:
                print("You already have an account.")
                Sign_up_Details()
            else:
                cu.execute("INSERT INTO CUSTOMER_LOGIN(USER_NAME,PASSWORD,PERMISSION_TYPE,C_ID)VALUES(?,?,?,?)",(Customer_UserName,Customer_Password,"Customer",Customer_ID))
                con.commit()
                Sign_up_Result(Customer_Name,Customer_AC_NO,Customer_UserName,Customer_Password)
    else:
        print("Customer name and date of birth do not match our records.")
    #-------------------------------------------------------------------------------------------------------------------

def Sign_up_Result(Customer_Name,Customer_AC_NO,Customer_UserName,Customer_Password):
    print("--------------------------------------------------------------------------------------------------------------")
    print("----------------------------------User account created successfully-------------------------------------------")
    print("--------------------------------------------------------------------------------------------------------------\n")
    print("                      Customer Name             : ",Customer_Name)
    print("                      Customer Account Number   : ",Customer_AC_NO)
    print("                      Customer User Name        : ",Customer_UserName)
    print("                      Customer User Name        : ",Customer_Password)
    print("\n\n")

    Out = input("Enter 1 for EXIT , 2 for Customer Login Page")
    if Out=="1":
        Thankyou_page()
    else:
        Customer_login()
#-------------------------------------------------------------------------------------------------------------------------


                                    #FUNCTIONS

#------------------------------Deposite Function--------------------------------------------------------------------------
def Deposite_Money(C_ID):

  
    D_Amount = int(input("                                Please Enter The Deposite amount : "))
    cu.execute("SELECT ACCOUNT_TYPE,ACCOUNT_NUMBER,BALANCE FROM ACCOUNT_DETAILS WHERE C_ID = ?",(C_ID,))
    Result_01 = cu.fetchall()
    cu.execute("SELECT MAX(DEPOSITE_ID) FROM DEPOSITE_DETAILS")
    Result_02 = cu.fetchall()
    Deposite_Id = int(Result_02[0][0])+1
    Referance_No = "REF" + str(Deposite_Id + 1000)
    New_D_Amount = D_Amount + int(Result_01[0][2])

#---------Data Inserting into Deposite table--------

    cu.execute("INSERT INTO DEPOSITE_DETAILS(DEPOSITE_ID,C_ID,DEPOSITE_AMOUNT,DATE,TIME,TRANSACATION_MODE,BRANCH_ID,REFERANCE_NO,STAFF_ID)VALUES(?,?,?,?,?,?,?,?,?)",(Deposite_Id,C_ID,D_Amount,Date_today,C_Time,"Online","---",Referance_No,"Customer"))
#---------Balance Updating in Account details--------    
    cu.execute("UPDATE ACCOUNT_DETAILS SET BALANCE = ? WHERE C_ID = ?",(New_D_Amount,C_ID,))

    ac_type = Result_01[0][0]
    ac_type = ac_type.upper()

    if ac_type == "SAVING":
        cu.execute("UPDATE SAVING_ACCOUNT_DETAILS SET BALANCE = ? WHERE C_ID = ?",(New_D_Amount,C_ID,))
    elif ac_type == "CURRENT":
        cu.execute("UPDATE CURRENT_ACCOUNT_DETAILS SET BALANCE = ? WHERE C_ID = ?",(New_D_Amount,C_ID,))
    elif ac_type == "FIXED":
        cu.execute("UPDATE FIXED_ACCOUNT_DETAILS SET BALANCE = ? WHERE C_ID = ?",(New_D_Amount,C_ID,))
    con.commit()

    print("---------------------------------------------------------------------------------------------------------------")
    print("---------------------------------------Customer Deposite Details-----------------------------------------------")
    print("---------------------------------------------------------------------------------------------------------------")
    print("                            Customer Name             : ",cutomer_Name_Global)
    print("                            Customer Account Number   : ",Result_01[0][1])
    print("                            Customer Account Type     : ",Result_01[0][0])
    print("                            Customer Account Balance  : ",New_D_Amount)

    print("\n\n")
    C_Account_Number = Result_01[0][1]
    Out=input("Enter 1 for EXIT , 2 for Customer Dash Board")
    if Out=="1":
        Thankyou_page()
    else:
        Customer_dashboard(cutomer_Name_Global,C_Account_Number,C_ID)
#-------------------------------------------------------------------------------------------------------------------------
        
#------------------------------Withdraw Function--------------------------------------------------------------------------
def Withdraw_Money(C_ID):

  
    W_Amount = int(input("                                Please Enter The Withdraw amount : "))
    cu.execute("SELECT ACCOUNT_TYPE,ACCOUNT_NUMBER,BALANCE FROM ACCOUNT_DETAILS WHERE C_ID = ?",(C_ID,))
    Result_01 = cu.fetchall()
    if W_Amount > Result_01[0][2]:
        print("Transaction declined: withdrawal exceeds balance.")
        Withdraw_Money(C_ID)
        return
    

    cu.execute("SELECT MAX(WITHDRAW_ID) FROM WITHDRAW_DETAILS")
    Result_02 = cu.fetchall()
    Withdraw_Id = int(Result_02[0][0])+1
    Referance_No = "REF" + str(Withdraw_Id + 1000)
    New_W_Amount = int(Result_01[0][2]) - W_Amount

#---------Data Inserting into WITHDRAW table--------

    cu.execute("INSERT INTO WITHDRAW_DETAILS(WITHDRAW_ID,C_ID,WITHDRAW_AMOUNT,DATE,TIME,TRANSACATION_MODE,BRANCH_ID,REFERANCE_NO,STAFF_ID)VALUES(?,?,?,?,?,?,?,?,?)",(Withdraw_Id,C_ID,W_Amount,Date_today,C_Time,"Online","---",Referance_No,"Customer"))
#---------Balance Updating in Account details--------    
    cu.execute("UPDATE ACCOUNT_DETAILS SET BALANCE = ? WHERE C_ID = ?",(New_W_Amount,C_ID,))

    ac_type = Result_01[0][0]
    ac_type = ac_type.upper()

    if ac_type == "SAVING":
        cu.execute("UPDATE SAVING_ACCOUNT_DETAILS SET BALANCE = ? WHERE C_ID = ?",(New_W_Amount,C_ID,))
    elif ac_type == "CURRENT":
        cu.execute("UPDATE CURRENT_ACCOUNT_DETAILS SET BALANCE = ? WHERE C_ID = ?",(New_W_Amount,C_ID,))
    elif ac_type == "FIXED":
        cu.execute("UPDATE FIXED_ACCOUNT_DETAILS SET BALANCE = ? WHERE C_ID = ?",(New_W_Amount,C_ID,))
    con.commit()

    print("---------------------------------------------------------------------------------------------------------------")
    print("---------------------------------------Customer Withdraw Details-----------------------------------------------")
    print("---------------------------------------------------------------------------------------------------------------")
    print("                            Customer Name             : ",cutomer_Name_Global)
    print("                            Customer Account Number   : ",Result_01[0][1])
    print("                            Customer Account Type     : ",Result_01[0][0])
    print("                            Customer Account Balance  : ",New_W_Amount)

    print("\n\n")
    C_Account_Number = Result_01[0][1]
    Out=input("Enter 1 for EXIT , 2 for Customer Dash Board")
    if Out=="1":
        Thankyou_page()
    else:
        Customer_dashboard(cutomer_Name_Global,C_Account_Number,C_ID)
    #---------------------------------------------------------------------------------------------------------------------

#------------------------------Transfer Function--------------------------------------------------------------------------    
def Transfer_Money(C_ID):
    T_Amount = int(input("                                Please Enter The Transfer amount : "))
    T_Account = input("                                Enter beneficiary Account Number for transfer : ")
    T_Name = input("                                Enter beneficiary name for transfer: ")
    cu.execute("SELECT ACCOUNT_TYPE,ACCOUNT_NUMBER,BALANCE FROM ACCOUNT_DETAILS WHERE C_ID = ?",(C_ID,))
    Result_01 = cu.fetchall()
    if T_Amount > Result_01[0][2]:
        print("Transaction declined: Transfer amount exceeds balance.")
        Transfer_Money(C_ID)
        return  
    cu.execute("SELECT C_ID,ACCOUNT_TYPE,BALANCE FROM ACCOUNT_DETAILS WHERE ACCOUNT_NUMBER = ?",(T_Account,))  # Validating Beneficiary account
    Result_02 = cu.fetchall()
    #print(Result_02)
    if not Result_02:
        print("Transaction declined: The transfer account number is invalid.")
        Transfer_Money(C_ID)
        return  
    Transfer_C_ID = Result_02[0][0] # Storing C_ID of Beneficiary

    cu.execute("SELECT MAX(TRANSFER_ID) FROM TRANSFER_DETAILS")
    Result_03 = cu.fetchall()

    if Result_03[0][0] is None:
        Transfer_Id = 101   # start from 1 if no records exist
    else:
        Transfer_Id = int(Result_03[0][0]) + 1
    
    Referance_No = "REF" + str(Transfer_Id + 1000)
    

    cu.execute("INSERT INTO TRANSFER_DETAILS(TRANSFER_ID,C_ID,TRANSFER_AMOUNT,DATE,TIME,TRANSACATION_MODE,T_C_ID,REFERANCE_NO,STAFF_ID)VALUES(?,?,?,?,?,?,?,?,?)",(Transfer_Id,C_ID,T_Amount,Date_today,C_Time,"Online",Transfer_C_ID,Referance_No,"Customer")) 
    
    ac_type = Result_02[0][1]
    ac_type = ac_type.upper()
    New_T_Amount = int(Result_02[0][2]) + T_Amount
    

    #----------- Storing Balance of Beneficiary--------------------
    if ac_type == "SAVING":
        cu.execute("UPDATE SAVING_ACCOUNT_DETAILS SET BALANCE = ? WHERE C_ID = ?",(New_T_Amount,Transfer_C_ID,))
    elif ac_type == "CURRENT":
        cu.execute("UPDATE CURRENT_ACCOUNT_DETAILS SET BALANCE = ? WHERE C_ID = ?",(New_T_Amount,Transfer_C_ID,))
    elif ac_type == "FIXED":
        cu.execute("UPDATE FIXED_ACCOUNT_DETAILS SET BALANCE = ? WHERE C_ID = ?",(New_T_Amount,Transfer_C_ID,))

    cu.execute("UPDATE ACCOUNT_DETAILS SET BALANCE = ? WHERE C_ID = ?",(New_T_Amount,Transfer_C_ID,))

    #----------- Storing Balance of Customer Account--------------------
    ac_type1 = Result_01[0][0]
    ac_type1 = ac_type1.upper()
    New_B_Amount = int(Result_01[0][2]) - T_Amount
    if ac_type1 == "SAVING":
        cu.execute("UPDATE SAVING_ACCOUNT_DETAILS SET BALANCE = ? WHERE C_ID = ?",(New_B_Amount,C_ID,))
    elif ac_type1 == "CURRENT":
        cu.execute("UPDATE CURRENT_ACCOUNT_DETAILS SET BALANCE = ? WHERE C_ID = ?",(New_B_Amount,C_ID,))
    elif ac_type1 == "FIXED":
        cu.execute("UPDATE FIXED_ACCOUNT_DETAILS SET BALANCE = ? WHERE C_ID = ?",(New_B_Amount,C_ID,))

    cu.execute("UPDATE ACCOUNT_DETAILS SET BALANCE = ? WHERE C_ID = ?",(New_B_Amount,C_ID,))

    con.commit()

    print("---------------------------------------------------------------------------------------------------------------")
    print("---------------------------------------Customer Withdraw Details-----------------------------------------------")
    print("---------------------------------------------------------------------------------------------------------------")
    print("                                        Trasfer Successfully")
    print("                            Customer Name             : ",cutomer_Name_Global)
    print("                            Beneficiary Name          : ",T_Name)
    print("                            Beneficiary Account Number: ",T_Account)
    print("                            Customer Account Balance  : ",New_B_Amount)

    print("\n\n")
    C_Account_Number = Result_01[0][1]
    Out=input("Enter 1 for EXIT , 2 for Customer Dash Board")
    if Out=="1":
        Thankyou_page()
    else:
        Customer_dashboard(cutomer_Name_Global,C_Account_Number,C_ID)
    #---------------------------------------------------------------------------------------------------------------------

    #------------------------------Account Details Function--------------------------------------------------------------------------    
def Account_Details(C_ID):
    cu.execute("SELECT * FROM CUSTOMER_DETAILS WHERE C_ID = ?",(C_ID,))
    Result_01 = cu.fetchall()
    cu.execute("SELECT * FROM ACCOUNT_DETAILS WHERE C_ID = ?",(C_ID,))
    Result_02 = cu.fetchall()

    
    print("---------------------------------------------------------------------------------------------------------------")
    print("---------------------------------------Customer Account Details-----------------------------------------------")
    print("---------------------------------------------------------------------------------------------------------------")
    print("                            Customer Name             : ",Result_01[0][1])
    print("                            Account Number            : ",Result_02[0][3])
    print("                            Date Of Birth             : ",Result_01[0][2])
    print("                            Adress                    : ",Result_01[0][3])
    print("                            Contact Number            : ",Result_01[0][4])
    print("                            Email Adress              : ",Result_01[0][5])
    print("                            National ID/Passport      : ",Result_01[0][6])
    print("                            Account Type              : ",Result_02[0][2])
    print("                            Balance                   : ",Result_02[0][4])
    print("                            Account Open Date         : ",Result_02[0][5])
    print("                            Account Status            : ",Result_02[0][6])

    print("\n\n")
    Out=input("Enter 1 for EXIT , 2 for Customer Dash Board :")
    if Out=="1":
        Thankyou_page()
    else:
        Customer_dashboard(cutomer_Name_Global,Result_02[0][3],C_ID)

    #------------------------------Change Password Function--------------------------------------------------------------------------   
def Change_Password(C_ID):
   
    cu.execute("SELECT PASSWORD FROM CUSTOMER_LOGIN WHERE C_ID = ?",(C_ID,))
    Result_01 = cu.fetchall()
    print("---------------------------------------------------------------------------------------------------------------")
    print("-------------------------------------------Change Password-----------------------------------------------------")
    print("---------------------------------------------------------------------------------------------------------------")
    old_pass = input("-------------------Enter Old Password      : ")
    New_pass = input("-------------------Enter New Password      : ")
    if old_pass == Result_01[0][0]:
        print("Old Password")
        cu.execute("UPDATE CUSTOMER_LOGIN SET PASSWORD = ? WHERE C_ID = ?",(New_pass,C_ID,))
        con.commit()
        print("---------------------------------------------------------------------------------------------------------------")
        print("-----------------------------Your password has been changed successfully.--------------------------------------")
        print("---------------------------------------------------------------------------------------------------------------")
        Out=input("Enter 1 for EXIT , 2 for Customer Dash Board :")
        if Out=="1":
            Thankyou_page()
        else:
            Customer_dashboard(cutomer_Name_Global,Customer_Account_No_Global,C_ID)
    else:
        print("Invalid Old Passwrd")
        Customer_dashboard(cutomer_Name_Global,Customer_Account_No_Global,C_ID)
#------------------------------------------------------------------------------------------------------------------------------
#------------------------------------------Mini Statement Function----------------------------------------------------------------------
def Mini_Statement(C_ID):
    print("--------------------------------------------------------------------------------------------------------------\n")
    From_Date = input("                                Please Enter The Starting Date(MM/DD/YY) : ")
    To_Date = input("                                Please Enter The Ending Date(MM/DD/YY) : ")

    Result_01=cu.execute("SELECT * FROM TRANSFER_DETAILS WHERE DATE >= ? AND DATE <= ? AND C_ID = ?",(From_Date, To_Date, C_ID,)) # Extract data from Transfer Details Table
    Result_01 = cu.fetchall()
    Result_02=cu.execute("SELECT * FROM WITHDRAW_DETAILS WHERE DATE >= ? AND DATE <= ? AND C_ID = ?",(From_Date, To_Date, C_ID,)) # Extract data from Withdraw Details Table
    Result_02 = cu.fetchall()
    Result_03=cu.execute("SELECT * FROM DEPOSITE_DETAILS WHERE DATE >= ? AND DATE <= ? AND C_ID = ?",(From_Date, To_Date, C_ID,)) # Extract data from DEPOSITE Details Table
    Result_03 = cu.fetchall()
    Result_04 = cu.execute("SELECT ACCOUNT_TYPE, ACCOUNT_NUMBER, BALANCE FROM ACCOUNT_DETAILS WHERE C_ID = ?",(C_ID,))
    Result_04 = cu.fetchall()
    
    print("---------------------------------------------------------------------------------------------------------------")
    print("------------------------------------------Mini Statement-------------------------------------------------------")
    print("---------------------------------------------------------------------------------------------------------------")
    print(" Name  : ",cutomer_Name_Global,"  Account Number : ",Result_04[0][1], "  Account Type : ",Result_04[0][0],"  Balance : ", Result_04[0][2])
    print("---------------------------------------------------------------------------------------------------------------")
    print("------------------------------------------Transfer Details-----------------------------------------------------")
    print("                       Date            REFERANCE NO             TRASFER AMOUNT                    ") 
    for Mini in Result_01:
        print("                    ", Mini[3],"          ", Mini[7], "                ", Mini[2])

    print("------------------------------------------Withdraw Details-----------------------------------------------------")
    print("                       Date            REFERANCE NO             TRASFER AMOUNT                    ") 
    for Mini2 in Result_02:
        print("                    ", Mini2[3],"          ", Mini2[7], "                ", Mini2[2])

    print("\n------------------------------------------Deposite Details-----------------------------------------------------")
    print("                       Date            REFERANCE NO             TRASFER AMOUNT                    ") 
    for Mini3 in Result_03:
        print("                    ", Mini3[3],"          ", Mini3[7], "                ", Mini3[2])
    print("\n---------------------------------------------------------------------------------------------------------------")

    print("\n\n")
    Out=input("Enter 1 for EXIT , 2 for Customer Dash Board")
    if Out=="1":
        Thankyou_page()
    else:
        Customer_dashboard(cutomer_Name_Global,Result_04[0][1],C_ID)
        
    
 #---------------------------------------------------------------------------------------------------------------------------   


#------------------------------Balance Function--------------------------------------------------------------------------
def C_check_balance(C_ID):

    cu.execute("SELECT FULL_NAME, ADRESS FROM CUSTOMER_DETAILS WHERE C_ID = ?",(C_ID,))
    Result_01 = cu.fetchall()
    #print(Result_01)
    F_Name = Result_01[0][0]
    C_Adress = Result_01[0][1]
    cu.execute("SELECT ACCOUNT_TYPE, ACCOUNT_NUMBER, BALANCE FROM ACCOUNT_DETAILS WHERE C_ID = ?",(C_ID,))
    Result_02 = cu.fetchall()
    C_Account_Type = Result_02[0][0]
    C_Account_Number = Result_02[0][1]
    C_Balancer = Result_02[0][2]

    print("--------------------------------------------------------------------------------------------------------------")
    print("-------------------------------------Customer Balance Details-------------------------------------------------")
    print("--------------------------------------------------------------------------------------------------------------\n")
    print("                      Customer Name             : ",F_Name)
    print("                      Customer Adress           : ",C_Adress)
    print("                      Customer Account Number   : ",C_Account_Number)
    print("                      Customer Account Type     : ",C_Account_Type)
    print("                      Customer Account Balance  : ",C_Balancer)

    print("\n\n")
    Out=input("Enter 1 for EXIT , 2 for Customer Dash Board")
    if Out=="1":
        Thankyou_page()
    else:
        Customer_dashboard(F_Name,C_Account_Number,C_ID)
        
#------------------------------------------------------------------------------------------------------------------------

#------------------------------View Customer Accounts--------------------------------------------------------------------

def View_Customer_Accounts():
    a=0
    
    Result_01=cu.execute("SELECT * FROM ACCOUNT_DETAILS")
    Result_01 = cu.fetchall()
    Result_02=cu.execute("SELECT * FROM CUSTOMER_DETAILS")
    Result_02 = cu.fetchall()

    print("---------------------------------------------------------------------------------------------------------------")
    print("------------------------------------------Customers Details----------------------------------------------------")
    print("---------------------------------------------------------------------------------------------------------------")
    print("|Customer ID | Name | ACCOUNT NUMBER | ACCOUNT TYPE | BALANCE | CONTACT NUMBER | DATE OPEN | STATUS |")
    print("\n")

    for R1 in Result_01:
        print(" ",R1[0]," ",Result_02[a][1]," ",R1[3]," ",R1[2]," ",R1[4]," ",Result_02[a][4]," ",R1[5]," ",R1[6])
        a+=1
    
    print("\n\n")
    Out=input("Enter 1 for EXIT , 2 for Staff Dash Board: ")
    if Out=="1":
        Thankyou_page_staff()
    else:
        Staff_dashboard(S_Staff_Name)
 #--------------------------------------------Search Customer---------------------------------------------------------------       
def Search_Customer():
    ac_no = input("Enter Account Number : ")
    Result_01=cu.execute("SELECT * FROM ACCOUNT_DETAILS WHERE ACCOUNT_NUMBER = ?",(ac_no,))
    Result_01 = cu.fetchall()
    if not Result_01: 
        print("Account number not found.")
        Search_Customer()
        #return
    Result_02=cu.execute("SELECT * FROM CUSTOMER_DETAILS WHERE C_ID = ?",(Result_01[0][0],))
    Result_02 = cu.fetchall()
    if not Result_02: 
            print("Account Details not found.")
            Search_Customer()
            #return

    print("---------------------------------------------------------------------------------------------------------------")
    print("------------------------------------------Customers Details----------------------------------------------------")
    print("---------------------------------------------------------------------------------------------------------------")
    print("|Customer ID | Name | ACCOUNT NUMBER | ACCOUNT TYPE | BALANCE | CONTACT NUMBER | DATE OPEN | STATUS |")
    print("\n")

    print(" ",Result_01[0][0]," ",Result_02[0][1]," ",Result_01[0][3]," ",Result_01[0][2]," ",Result_01[0][4]," ",Result_02[0][4]," ",Result_01[0][5]," ",Result_01[0][6])
    
    
    print("\n\n")
    Out=input("Enter 1 for EXIT , 2 for Staff Dash Board: ")
    if Out=="1":
        Thankyou_page_staff()
    else:
        Staff_dashboard(S_Staff_Name)

#----------------------------------------------------------------------------------------------------------------------------------------


#--------------------------------------------------Create Customer Account------------------------------------------------------------------------
def Create_Customer_Account():
    cu.execute("SELECT MAX(C_ID) FROM ACCOUNT_DETAILS")
    Result_01 = cu.fetchall()
    if Result_01[0][0] is None:
        c_id  = 101   # start from 1 if no records exist
    else:
        c_id  = int(Result_01[0][0]) + 1

    Name = input("Enter the Customer Name :")
    Dob = input("Enter the Date of Birth DD/MM/YYYY :")
    adress1 = input("Enter the adress :")
    phone1 = int(input("Enter the phone number :"))
    email = input("Enter the email id :")

    #---------email Validation---------
    check=re.findall(".com$",email)
    if check:
        
        if check:
            print("")
        else:
            print("invalid email id ")
            Create_Customer_Account()
    else:
        print("invalid email id")
        Create_Customer_Account()


    
    n_id = input("Enter the national id or passport number :")

    cu.execute("SELECT MAX(ACCOUNT_NUMBER) FROM ACCOUNT_DETAILS")
    Result_02 = cu.fetchall()
    if Result_02[0][0] is None:
        Ac_Number1  = 1005001   # start from 1 if no records exist
    else:
        #print(Result_02[0][0])
        Ac_Number1 = int(Result_02[0][0]) + 1

    Ac_id = c_id + 9000
    Ac_type = input("Enter the type account(Saving,Current & Fixed) :")
    deposite = input("Enter the Deposite :")
   
    
    cu.execute("INSERT INTO CUSTOMER_DETAILS(C_ID,FULL_NAME,DATE_OF_BIRTH,ADRESS,PHONE_NUMBER,EMAIL_ID,NATIONAL_ID_PASSPORT)VALUES(?,?,?,?,?,?,?)",(c_id,Name,Dob,adress1,phone1,email,n_id))
    cu.execute("INSERT INTO ACCOUNT_DETAILS(C_ID,ACCOUNT_ID,ACCOUNT_TYPE,ACCOUNT_NUMBER,BALANCE,DATE_OPEN,STATUS)VALUES(?,?,?,?,?,?,?)",(c_id,Ac_id,Ac_type,Ac_Number1,deposite,Date_today,"Active"))
    if Ac_type == "Saving":
        cu.execute("INSERT INTO SAVING_ACCOUNT_DETAILS(C_ID,ACCOUNT_ID,ACCOUNT_TYPE,ACCOUNT_NUMBER,BALANCE,DATE_OPEN,STATUS)VALUES(?,?,?,?,?,?,?)",(c_id,Ac_id,Ac_type,Ac_Number1,deposite,Date_today,"Active"))
    if Ac_type == "Current":
        cu.execute("INSERT INTO CURRENT_ACCOUNT_DETAILS(C_ID,ACCOUNT_ID,ACCOUNT_TYPE,ACCOUNT_NUMBER,BALANCE,DATE_OPEN,STATUS)VALUES(?,?,?,?,?,?,?)",(c_id,Ac_id,Ac_type,Ac_Number1,deposite,Date_today,"Active"))
    if Ac_type == "Fixed":
        cu.execute("INSERT INTO FIXED_ACCOUNT_DETAILS(C_ID,ACCOUNT_ID,ACCOUNT_TYPE,ACCOUNT_NUMBER,BALANCE,DATE_OPEN,STATUS)VALUES(?,?,?,?,?,?,?)",(c_id,Ac_id,Ac_type,Ac_Number1,deposite,Date_today,"Active"))
    con.commit()
    print("--------------------------------------------------------------------------------------------------------------")
    print("-------------------------------------Customer account created successfully.------------------------------------")
    print("--------------------------------------------------------------------------------------------------------------\n")
    print("                      Customer Name             : ",Name)
    print("                      Customer Adress           : ",adress1)
    print("                      Customer Account Number   : ",Ac_Number1)
    print("                      Customer Account Type     : ",Ac_type)
    print("                      Customer Account Balance  : ",deposite)
    print("--------------------------------------------------------------------------------------------------------------\n")
    print("\n\n")
    Out=input("Enter 1 for EXIT , 2 for Staff Dash Board: ")
    if Out=="1":
        Thankyou_page_staff()
    else:
        Staff_dashboard(S_Staff_Name)
#------------------------------------------------------------------------------------------------------------------------

#--------------------------------------------Update Customer Details-----------------------------------------------------
def Update_Customer_Details():
    print("-------Update_Customer_Details-----")

#------------------------------------------------------------------------------------------------------------------------

#--------------------------------------------Delete Customer Details-----------------------------------------------------    


def Delete_Customer_Account():
    ac_no = input("Enter Account Number : ")
    Result_01=cu.execute("SELECT * FROM ACCOUNT_DETAILS WHERE ACCOUNT_NUMBER = ?",(ac_no,))
    Result_01 = cu.fetchall()
    if not Result_01: 
        print("Account number not found.")
        #Delete_Customer_Account()
        return
    Result_02=cu.execute("SELECT * FROM CUSTOMER_DETAILS WHERE C_ID = ?",(Result_01[0][0],))
    Result_02 = cu.fetchall()
    if not Result_02: 
        print("Customer Details not found.")
        #Delete_Customer_Account()
        return
    print(Result_02)
    print(Result_01)

    if Result_01[0][2]:
        status = Result_01[0][2].upper()

    # DELETE RECORDS FROM EACH TABLE
    if status == "SAVING":
        cu.execute("DELETE FROM SAVING_ACCOUNT_DETAILS WHERE C_ID = ?",(Result_01[0][0],))
    if status == "CURRENT":
        cu.execute("DELETE FROM CURRENT_ACCOUNT_DETAILS WHERE C_ID = ?",(Result_01[0][0],))
    if status == "FIXED":
        cu.execute("DELETE FROM FIXED_ACCOUNT_DETAILS WHERE C_ID = ?",(Result_01[0][0],))

    cu.execute("DELETE FROM ACCOUNT_DETAILS WHERE c_ID = ?",(Result_01[0][0],))
    cu.execute("DELETE FROM CUSTOMER_DETAILS WHERE c_ID = ?",(Result_01[0][0],))
    con.commit()

    print("---------------------------------------------------------------------------------------------------------------")
    print("-----------------------------This Account has been Deleted successfully.--------------------------------------")
    print("---------------------------------------------------------------------------------------------------------------")
   #------------------------------------------------------------------------------------------------------------------------------- 
    



   #------------------------------Change Password Function--------------------------------------------------------------------------   
def Change_Password_Staff(C_ID):
    
    cu.execute("SELECT PASSWORD FROM STAFF_LOGIN WHERE STAFF_ID = ?",(C_ID,))
    Result_01 = cu.fetchall()
    if not Result_01:
        print("No login record found for this Staff/Customer ID.")
        Staff_dashboard(S_Staff_Name)
        #return


    
    print("---------------------------------------------------------------------------------------------------------------")
    print("-------------------------------------------Change Password-----------------------------------------------------")
    print("---------------------------------------------------------------------------------------------------------------")
    old_pass = input("-------------------Enter Old Password      : ")
    New_pass = input("-------------------Enter New Password      : ")
    if old_pass == Result_01[0][0]:
        cu.execute("UPDATE STAFF_LOGIN SET PASSWORD = ? WHERE STAFF_ID = ?",(New_pass,C_ID,))
        con.commit()
        print("---------------------------------------------------------------------------------------------------------------")
        print("-----------------------------Your password has been changed successfully.--------------------------------------")
        print("---------------------------------------------------------------------------------------------------------------")
        Out=input("Enter 1 for EXIT , 2 for Staff Dash Board :")
        if Out=="1":
            Thankyou_page_staff()
        else:
            Staff_dashboard(S_Staff_Name)
    else:
        print("Invalid Old Passwrd")
        Staff_dashboard(S_Staff_Name)
#------------------------------------------------------------------------------------------------------------------------------
  








#------------------------------Final View--------------------------------------------------------------------------------   
def Thankyou_page():
    print("--------------------------------------------------------------------------------------------------------------\n")
    print("                       Thank You," , cutomer_Name_Global , " For banking with us. ",)
    print("                       You have successfully logged out of your account.\n")
    print("--------------------------------------------------------------------------------------------------------------")
#------------------------------------------------------------------------------------------------------------------------

#------------------------------Final View--------------------------------------------------------------------------------   
def Thankyou_page_staff():
    print("--------------------------------------------------------------------------------------------------------------\n")
    print("                       Thank You," , S_Staff_Name , " For banking with us. ",)
    print("                       You have successfully logged out of your account.\n")
    print("--------------------------------------------------------------------------------------------------------------")
#------------------------------------------------------------------------------------------------------------------------




#------------------------------------------------------------------------------------------------------------------------




#------------------- Login Customer-----------------------

def Login_Authentication(U_Name,U_password):

    global User_name,c_passwrd,U_permission_Type,User_c_id,cutomer_Name_Global

    cu.execute("SELECT * FROM CUSTOMER_LOGIN WHERE USER_NAME =? AND PASSWORD = ?",(U_Name,U_password,))
    Result_01 =cu.fetchall()
    if Result_01:
        # for a1 in Result_01:
        #  print(a1)
        User_name,c_passwrd,U_permission_Type,User_c_id = Result_01[0] # Extract Data From Result_01
        cu.execute("SELECT FULL_NAME FROM CUSTOMER_DETAILS WHERE C_ID =?",(User_c_id,))
        Result_02 =cu.fetchall()
        Customer_Name = Result_02[0][0] # Extract Data From Result_02

        cu.execute("SELECT ACCOUNT_NUMBER FROM ACCOUNT_DETAILS WHERE C_ID =?",(User_c_id,))
        Result_03 =cu.fetchall()       
        Customer_Account_No = Result_03[0][0]
        cutomer_Name_Global = Customer_Name
        Customer_dashboard(Customer_Name,Customer_Account_No,User_c_id,)
    else:
        print("Invalid username or password.")
        Customer_login()

#------------------- Login Staff-----------------------

def Staff_Login_Authentication(U_Name,U_password):

    global S_User_ID,S_Staff_Name,Staff_ID
    cu.execute("SELECT STAFF_ID FROM STAFF_LOGIN WHERE USER_NAME =? AND PASSWORD = ?",(U_Name,U_password,))
    Result_01 = cu.fetchall()
   # print(Result_01)
    if Result_01:
        #print("True")
        S_User_ID = Result_01[0][0]
        Staff_ID = S_User_ID
        cu.execute("SELECT STAF_NAME FROM STAFF_DETAILS WHERE STAFF_ID =?",(S_User_ID,))
        Result_02 =cu.fetchall()
        S_Staff_Name = Result_02[0][0]
        Staff_dashboard(S_Staff_Name)
    else:
        print("Invalid username or password.")
        Staff_login()

#------------------------------------------------------------


#------------------- Staff choice menu -----------------------

def Staff_Choice_board(Choice):
    if Choice == 1:
        View_Customer_Accounts()
    elif Choice == 2:
        Search_Customer()
    elif Choice == 3:
        Create_Customer_Account()
    elif Choice == 4:
        Delete_Customer_Account()
    elif Choice == 5:
        Change_Password_Staff(Staff_ID)
    elif Choice == 6:
        Thankyou_page_staff()
    else:
        print("Invalid Entry")
        Staff_dashboard()

#------------------- Customer choice menu -----------------------
def Customer_Choice_board(Choice,User_ID):
    if Choice == 1:
        C_check_balance(User_ID)
    elif Choice == 2:
        Deposite_Money(User_ID)
    elif Choice == 3:
        Withdraw_Money(User_ID)
    elif Choice == 4:
        Transfer_Money(User_ID)
    elif Choice == 5:
        Mini_Statement(User_ID)
    elif Choice == 6:
        Change_Password(User_ID)
    elif Choice == 7:
        Account_Details(User_ID)  
    elif Choice == 8:
        Thankyou_page()
    else:
        print("Invalid Entry")
        Customer_dashboard()







display_Menu()
# Customer_login()
# Customer_dashboard()


# while a == True:
#     Create_account()
#     Continue = input("Enter '1' FOR CONTINUE")
#     if Continue == "1":
#         a = True
#     else:
#         a = False



con.close() # if you finish work only run this comment



