------------------------------------------------------------------------------------------------------------------------ 
                         Bank Management System
------------------------------------------------------------------------------------------------------------------------
Abstract:

This project features a lightweight application designed to execute digital banking operations efficiently. The primary 
objective of this Bank Management System is to fully automate core banking tasks that were traditionally performed manually,
 including account creation, balance inquiry, cash deposit, cash withdrawal, and transaction logging. The application logic 
is implemented using Python, while SQLite is used as the relational database to store and manage data securely.

Key Feature: 
• Account Management : AccounT Create new account , update details, and Close accounts.
• Transactions : Deposit money, withdraw cash, Transfer cash to another account.
• Inquiries : Check Current Balance and view transaction history or account statements.
• Administration : Login for admin / Customer & Signup


----------------------------------------------------------------------------------------------------------------------
Data Base design

Account Management:
• CUSTOMER_DETAILS
• ACCOUNT_DETAILS
• SAVINGS_ACCOUNT_DETAILS
• CURRENT_ACCOUNT_DETAILS
• FIXED_ACCOUNT_DETAILS

TRANSCATIONS:
• DEPOSITE_DETAILS
• WITHDRAW_DETAILS
• TRANSFER_DETAILS

ADMINISTRATION:
• STAFF_DETAILS
• CUSTOMER_LOGIN
• STAFF_LOGIN
